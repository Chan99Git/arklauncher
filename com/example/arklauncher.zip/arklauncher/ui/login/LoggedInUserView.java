package com.example.arklauncher.ui.login;

class LoggedInUserView
{
  private String displayName;
  
  LoggedInUserView(String paramString)
  {
    this.displayName = paramString;
  }
  
  String getDisplayName()
  {
    return this.displayName;
  }
}


/* Location:              C:\Users\admin\Desktop\dex2jar-2.0\dex2jar-2.0\3_方舟代理.jar!\com\example\arklaunche\\ui\login\LoggedInUserView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */